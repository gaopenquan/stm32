#ifndef _XUNXIAN_H
#define _XUNXIAN_H

#include "board.h"


#define HW_max 12  //��·�Ҷ�

//��ȡ�Ҷȴ�����״̬

#define   IN1 		 (  (DL_GPIO_readPins(Grayscale_IN1_PORT, Grayscale_IN1_PIN)     >0)   ?  1  :  0  )
#define   IN2 		 (  (DL_GPIO_readPins(Grayscale_IN2_PORT, Grayscale_IN2_PIN)     >0)   ?  1  :  0  )
#define   IN3 		 (  (DL_GPIO_readPins(Grayscale_IN3_PORT, Grayscale_IN3_PIN)     >0)   ?  1  :  0  )
#define   IN4 		 (  (DL_GPIO_readPins(Grayscale_IN4_PORT, Grayscale_IN4_PIN)     >0)   ?  1  :  0  )       
#define   IN5 		 (  (DL_GPIO_readPins(Grayscale_IN5_PORT, Grayscale_IN5_PIN)     >0)   ?  1  :  0  ) 
#define   IN6 		 (  (DL_GPIO_readPins(Grayscale_IN6_PORT, Grayscale_IN6_PIN)     >0)   ?  1  :  0  ) 
#define   IN7 		 (  (DL_GPIO_readPins(Grayscale_IN7_PORT, Grayscale_IN7_PIN)     >0)   ?  1  :  0  ) 
#define   IN8 		 (  (DL_GPIO_readPins(Grayscale_IN8_PORT, Grayscale_IN8_PIN)     >0)   ?  1  :  0  ) 
#define   IN9 		 (  (DL_GPIO_readPins(Grayscale_IN9_PORT, Grayscale_IN9_PIN)     >0)   ?  1  :  0  ) 
#define   IN10 		 (  (DL_GPIO_readPins(Grayscale_IN10_PORT,Grayscale_IN10_PIN)    >0)   ?  1  :  0  )
#define   IN11 		 (  (DL_GPIO_readPins(Grayscale_IN11_PORT,Grayscale_IN11_PIN)    >0)   ?  1  :  0  )
#define   IN12 		 (  (DL_GPIO_readPins(Grayscale_IN12_PORT,Grayscale_IN12_PIN)    >0)   ?  1  :  0  )



/*��������*/
uint16_t Sensor_GetState(void);
uint16_t SearchRun(void);
void gray_check(void);

/*��������*/
extern uint8_t stop_way;
extern uint8_t sensor_val[HW_max];
extern int16_t gray_status[2],gray_status_backup[2][20];
extern uint16_t gray_state;//��ǰ�Ҷ�״̬
extern uint32_t gray_status_worse;	


//��ʼ��	
void xunxian_init(void);
uint16_t Sensor_GetState(void);
void gray_check(void);


#endif

