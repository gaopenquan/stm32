#ifndef _CONTROL_H
#define _CONTROL_H

#include "board.h"
#include "motor.h"
#include "Key.h"
//#include "xunxian.h"

uint8_t Turn_Off(void);
int Read_Encoder(uint8_t carl);
void control(void);
int Angle_PID(int angle,int Target);
void Key(void);
int Position_PID (int Encoder,int Target);
#endif
